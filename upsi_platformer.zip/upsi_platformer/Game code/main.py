import pygame
from pygame.locals import *
from pygame import mixer
from game_objects import *

pygame.mixer.pre_init(44100, -16, 2, 512)
mixer.init()
pygame.init()

run= True
while run:
    clock.tick(fps)

    screen.blit(bg_img, (0, 0))
    screen.blit(sun_img, (100, 100))

    if main_menu:
        if exit_button.draw():
            run = False
        if start_button.draw():
            main_menu = False
    else:
        world.draw()

        if game_over == 0:
            blob_group.update()
            platform_group.update()

            if pygame.sprite.spritecollide(player, coin_group, True):
                score += 1
                coin_fx.play()

            draw_text('X ' + str(score), font_score, white, tile_size - 10, 10)

        blob_group.draw(screen)
        platform_group.draw(screen)
        lava_group.draw(screen)
        coin_group.update()
        coin_group.draw(screen) 
        exit_group.draw(screen)

        game_over = player.update(game_over, world)

        if game_over == -1:
            if restart_button.draw():
                world = reset_level(level)
                game_over = 0
                score = 0

        if game_over == 1:
            level += 1
            if level <= max_levels:
                world = reset_level(level)
                game_over = 0
            else:
                draw_text('YOU WIN!', font, blue, (screen_width // 2) - 140, screen_height // 2)
                if restart_button.draw():
                    level = 1
                    world = reset_level(level)
                    game_over = 0
                    score = 0

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False

    pygame.display.update()

pygame.quit()